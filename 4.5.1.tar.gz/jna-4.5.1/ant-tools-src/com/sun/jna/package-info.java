/**
 * <p>The build script is expected to build a minimal set of classes that are
 * required to execute this. At the time of writing these are:</p>
 *
 * <ul>
 * <li>{@link com.sun.jna.ELFAnalyser}</li>
 * <li>{@link com.sun.jna.CalcAndroidVersion}</li>
 * </ul>
 */
package com.sun.jna;
